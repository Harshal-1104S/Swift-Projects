//
//  WeatherReportAppApp.swift
//  WeatherReportApp
//
//  Created by Mehta, Harshal on 2025-07-09.
//

import SwiftUI

@main
struct WeatherReportAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
